<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: HEAD, GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method,Access-Control-Request-Headers, Authorization");
header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];
if ($method == "OPTIONS") {
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method,Access-Control-Request-Headers, Authorization");
header("HTTP/1.1 200 OK");
die();
}


require "config.php";

    
     if( isset($_POST['fotos']) and isset($_POST['detalles']) and isset($_POST['codigos']) and isset($_POST['iduser'])  ) {
         
         $foto=$_POST['fotos'];
         $detalle=$_POST['detalles'];
         $codigo=$_POST['codigos'];
         $iduser=$_POST['iduser'];
         
       $sql = "INSERT INTO article(id,foto,detalle,codigo,iduser) VALUES(default,'$foto','$detalle','$codigo','$iduser')";
    

    if (mysqli_query($con, $sql)) {
         $clientes[] = array('mensaje'=> "Articulo Almacenado");
  } else {
       $clientes[] = array('mensaje'=> "Articulo no Almacenado");
  }
     }else{
          $clientes[] = array('mensaje'=> "Articulo no Almacenado");
     }
     

    
   
$json_string = json_encode($clientes);
echo $json_string;
?>