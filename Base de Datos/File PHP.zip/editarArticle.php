<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: HEAD, GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method,Access-Control-Request-Headers, Authorization");
header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];
if ($method == "OPTIONS") {
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method,Access-Control-Request-Headers, Authorization");
header("HTTP/1.1 200 OK");
die();
}


require "config.php";

    
     if(isset($_POST['id']) and isset($_POST['fotos']) and isset($_POST['detalles']) and isset($_POST['codigos']) and isset($_POST['iduser'])  ) {
         $id=$_POST['id'];
         $foto=$_POST['fotos'];
         $detalle=$_POST['detalles'];
         $codigo=$_POST['codigos'];
         $iduser=$_POST['iduser'];
         
       $sql = "UPDATE article SET foto='$foto',detalle='$detalle',codigo='$codigo' WHERE id='$id'";
    

    if (mysqli_query($con, $sql)) {
         $clientes[] = array('mensaje'=> "Articulo Editado");
  } else {
       $clientes[] = array('mensaje'=> "Articulo no Editado 1");
  }
     }else{
          $clientes[] = array('mensaje'=> "Articulo no Editado 2");
     }
     

    
   
$json_string = json_encode($clientes);
echo $json_string;
?>